from django.db import models
# Create your models here.
class RegisterClas(models.Model):
    name = models.CharField(max_length=320)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=360)

class Task(models.Model):
    PRIORITY_CHOICES = [
        ('high', 'High'),
        ('medium', 'Medium'),
        ('low', 'Low'),
    ]
    
    title = models.CharField(max_length=200)
    description = models.TextField()
    due_date = models.DateTimeField()
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES)
    assigned_to = models.ForeignKey(RegisterClas, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.title
