from django.contrib import admin
from .models import RegisterClas,Task
class RegistrationAdmin(admin.ModelAdmin):
    list_display=["name","email"]
    list_filter=['name','email']
    list_search =['name','email']
admin.site.register(RegisterClas,RegistrationAdmin)

class TaskdisplayAdmin(admin.ModelAdmin):
    list_display=['title','description','due_date','priority']
    list_filter=['due_date','priority']
    list_search =['due_date','priority']
admin.site.register(Task,TaskdisplayAdmin)
# Register your models here.
    