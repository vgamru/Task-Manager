from django.shortcuts import render,get_object_or_404,redirect
from .models import RegisterClas,Task
from django.contrib import messages

# Create your views here.
def userindex(request):
    return render(request, 'index.html')
def userregister(request):
    if request.method == 'POST':
        user_name = request.POST.get("name")
        user_email = request.POST.get("email")
        user_password = request.POST.get("password")
        
        

        if not RegisterClas.objects.filter(email = user_email).exists():
            user_register = RegisterClas(name=user_name,email=user_email,password=user_password)
            user_register.save()
            return render(request,'login.html')
        else:
            messages.error(request,"Already registered this email")
            return render(request,'register.html')
    return render(request,'register.html')

def userlogin(request):
    global user_pk, name_user
    if request.method == 'POST':
        user_email = request.POST.get('email')
        user_password = request.POST.get('password')
        if RegisterClas.objects.filter(email=user_email, password=user_password).exists():
            obj = RegisterClas.objects.filter(email=user_email, password=user_password) #fetch the data
            for i in obj:
                print(i.pk)#primary key
                user_pk = i.pk
                name_user = i.name
            tasks = Task.objects.filter(assigned_to_id=user_pk).order_by('-due_date', 'priority')
            return render(request, "dashboard.html", {'tasks': tasks, 'name': name_user, 'assigned_to_id': user_pk})
        else:
            messages.error(request,"Invalid Login")
            return render(request,'login.html')
    return render(request,'login.html')

def add_task(request):
    if request.method == 'POST':
        task_title = request.POST.get('title')
        task_description = request.POST.get('description')
        task_level = request.POST.get('level')
        task_duedate = request.POST.get('duedate')


        task_details = Task(title=task_title, description=task_description, priority=task_level, due_date=task_duedate, assigned_to_id=user_pk )
        task_details.save()
        return redirect(dashboard)
    return render(request,'add_task.html')  

def dashboard(request):
    sort = request.GET.get('sort')
    duedate = request.GET.get('sort')
    search_query = request.GET.get('search')
    task = Task.objects.filter(assigned_to_id=user_pk)
    if sort == 'priority':
        task = task.order_by('-priority')
    elif sort == 'due_date':
        task = task.order_by('due_date')
    if search_query:
        task = task.filter(title__icontains=search_query)
    return render(request,"dashboard.html",{'tasks':task, 'name':name_user, 'assigned_to_id': user_pk})

def delete_task(request,id):
    task = Task.objects.get(id=id)
    task.delete()
    
    task = Task.objects.filter(assigned_to_id = user_pk)
    return render(request,"dashboard.html",{'tasks':task, 'name':name_user, 'assigned_to_id': user_pk})

def update_task(request,id):
    obj = get_object_or_404(Task,id = id)
    if request.method == "POST":
        update_task_title = request.POST.get('title')
        update_task_description = request.POST.get('description')
        update_task_level = request.POST.get('level')
        update_task_duedate = request.POST.get('duedate')

        obj.title = update_task_title
        obj.description = update_task_description
        obj.due_date = update_task_duedate
        obj.priority = update_task_level
        obj.save()
        return redirect(dashboard)
    #task = Task.objects.filter(assigned_to_id = user_pk)
    #return render(request,'update.html',{'tasks':task})
    return render(request, 'update.html', {'task': obj})

